<?php
/* Plantilla de ejemplo PHP que muestra información del servidor */
phpinfo();