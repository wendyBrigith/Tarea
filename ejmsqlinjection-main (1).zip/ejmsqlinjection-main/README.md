# Ejemplo de inyección SQL
Contiene código en PHP, con conexión a una base de datos con una sola tabla, que almacena un solo registro con campos de username y password. La base de datos está en Mysql.
El ejemplo trata de vulnerabilidad e inyección SQL
